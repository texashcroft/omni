import { KnowledgeBase } from "@/components/knowledge-base"

export default function KnowledgeBasePage() {
  return <KnowledgeBase />
}

